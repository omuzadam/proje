<?php

        require_once ("../DataLayer/DB.php");
        require_once ('../LogicLayer/Product.php');
class ProductManagement
{
    public static function getProducts(){

        $conn = new DB();
        $query = "select * from product ORDER by productID";
        $result = $conn->getDataTable($query);
        $allProducts = array();

        //if ($result->num_rows <= 0 ) {
            while ($row = $result->fetch_assoc()) {
                $productobj = new Product($row["productID"], $row["productName"],$row["containerID"], $row["cargoNumber"], $row["cargoCompanyName"],$row["departureCity"], $row["arrivalCity"]);
                array_push($allProducts, $productobj);
            }
            return $allProducts;
        //
    }

       public static function insertProduct($name,$barcode,$cargo,$cargoname,$departure,$arrival) {
        $conn = new DB();
        $success = $conn->executeQuery("INSERT INTO product(productName, containerID,cargoNumber,cargoCompanyName,departureCity,arrivalCity) VALUES ('$name', '$barcode', '$cargo', '$cargoname', '$departure', '$arrival')");
        return $success;
    }

 public static function deleteProduct($id) {
            require_once ("../DataLayer/DB.php");
            $conn = new DB();
            $success = $conn->executeQuery("DELETE FROM product WHERE productID = '$id'");
            return $success;
        }
        public static function editProduct($id,$name,$barcode,$cargo,$cargoname,$departure,$arrival) {
            require_once ("../DataLayer/DB.php");
            $conn = new DB();
            $success = $conn->executeQuery("UPDATE product set productName = '$name', containerID ='$barcode' , cargoNumber ='$cargo', cargoCompanyName ='$cargoname', departureCity ='$departure', arrivalCity ='$arrival' WHERE productID='$id'");
            return $success;
        }

        public static function getProduct($id){

        require_once ("../DataLayer/DB.php");
        require_once ('../LogicLayer/Product.php');
        $conn = new DB();
        $query = "select * from product where productID = '$id' ORDER by productID ";
        $result = $conn->getDataTable($query);
        $allProducts = array();

        //if ($result->num_rows <= 0 ) {
            while ($row = $result->fetch_assoc()) {
                $productobj = new Product($row["productID"], $row["productName"],$row["containerID"], $row["cargoNumber"], $row["cargoCompanyName"],$row["departureCity"], $row["arrivalCity"]);
                array_push($allProducts, $productobj);
            }
            return $allProducts;
        //
    }

 
}


?>

