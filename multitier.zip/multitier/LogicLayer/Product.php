<?php

/**
 * Created by PhpStorm.
 * User: Emre
 * Date: 6.5.2017
 * Time: 10:56
 */
class Product
{
    private $id;
    private $name;
    private $barcode;
    private $cargo;
    private $cargoname;
    private $departure;
    private $arrival;



    function __construct($id = NULL,$name = NULL,$barcode = NULL,$cargo = NULL,$cargoname = NULL,$departure = NULL,$arrival = NULL)
    {
        $this->id = $id;
        $this->name = $name;
        $this->barcode = $barcode;
        $this->cargo = $cargo;
        $this->cargoname = $cargoname;
        $this->departure = $departure;
        $this->arrival = $arrival;
    }

    public function getId()
    {
        return $this->id;
    }

    public function getName()
    {
        return $this->name;
    }
     public function getBarcode()
    {
        return $this->barcode;
    }

    public function getCargo()
    {
        return $this->cargo;
    }
       public function getCargoname()
    {
        return $this->cargoname;
    }
     public function getDeparture()
    {
        return $this->departure;
    }

    public function getArrival()
    {
        return $this->arrival;
    }
}