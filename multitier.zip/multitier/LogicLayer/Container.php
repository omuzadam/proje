<?php

/**
 * Created by PhpStorm.
 * User: Emre
 * Date: 6.5.2017
 * Time: 10:56
 */
class Container
{
    private $barcode;
    private $capacity;
    private $departure;
    private $arrival;




    function __construct($barcode = NULL,$capacity = NULL,$departure = NULL,$arrival = NULL)
    {
        $this->barcode = $barcode;
        $this->capacity = $capacity;
        $this->departure = $departure;
        $this->arrival = $arrival;
    }

    public function getBarcode()
    {
        return $this->barcode;
    }

    public function getCapacity()
    {
        return $this->capacity;
    }
     public function getDeparture()
    {
        return $this->departure;
    }

    public function getArrival()
    {
        return $this->arrival;
    }
}