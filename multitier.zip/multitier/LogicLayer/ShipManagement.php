<?php


class WorkerManagement
{
    public static function login($username,$password){
        require_once ("../DataLayer/DB.php");
        $conn = new DB();
        $con = $conn->getConnection();
        $username = mysqli_real_escape_string($con,$username);
        $password = mysqli_real_escape_string($con,$password);
        $sql = "SELECT * FROM worker WHERE workerUserName='$username' and workerPassword='$password'";
        $result = mysqli_query($con,$sql) or die(mysql_error());
        $rows = mysqli_num_rows($result);
        return $rows;
    }
}


?>