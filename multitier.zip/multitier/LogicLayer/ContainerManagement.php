<?php

        require_once ("../DataLayer/DB.php");
        require_once ('../LogicLayer/Container.php');
class ContainerManagement
{
    public static function getContainers(){

        $conn = new DB();
        $query = "select * from container ORDER by containerBarcode";
        $result = $conn->getDataTable($query);
        $allContainers = array();

        //if ($result->num_rows <= 0 ) {
            while ($row = $result->fetch_assoc()) {
                $containerobj = new Container($row["containerBarcode"], $row["capacity"],$row["departureCity"], $row["arrivalCity"]);
                array_push($allContainers, $containerobj);
            }
            return $allContainers;
        //
    }

       public static function insertNewContainer($barcode,$capacity,$departure,$arrival) {
        $conn = new DB();
        $success = $conn->executeQuery("INSERT INTO container(containerBarcode, capacity, departureCity,arrivalCity) VALUES ('$barcode', '$capacity', '$departure', '$arrival')");
        return $success;
    }

 public static function deleteContainer($barcode) {
            require_once ("../DataLayer/DB.php");
            $conn = new DB();
            $success = $conn->executeQuery("DELETE FROM container WHERE containerBarcode = '$barcode'");
            return $success;
        }
        public static function editContainer($barcode,$capacity,$departure,$arrival) {
            require_once ("../DataLayer/DB.php");
            $conn = new DB();
            $success = $conn->executeQuery("UPDATE container set capacity = '$capacity', departureCity ='$departure' , arrivalCity ='$arrival' WHERE containerBarcode='$barcode'");
            return $success;
        }

        public static function getContainer($barcode){

        require_once ("../DataLayer/DB.php");
        require_once ('../LogicLayer/Container.php');
        $conn = new DB();
        $query = "select * from container where containerBarcode = '$barcode' ORDER by containerBarcode ";
        $result = $conn->getDataTable($query);
        $allContainers = array();

        //if ($result->num_rows <= 0 ) {
            while ($row = $result->fetch_assoc()) {
                $containerobj = new Container($row["containerBarcode"], $row["capacity"],$row["departureCity"], $row["arrivalCity"]);
                array_push($allContainers, $containerobj);
            }
            return $allContainers;
        //
    }


}


?>

