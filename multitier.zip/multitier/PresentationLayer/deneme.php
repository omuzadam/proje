<?php 
	include_once('/storage/ssd1/934/1742934/public_html/LogicLayer/AdminManager.php');
	include_once('/storage/ssd1/934/1742934/public_html/DataLayer/DB.php');
        include_once('/storage/ssd1/934/1742934/public_html/LogicLayer/addCountry.php');
	
   if(isset($_POST["citylist"]) && isset($_POST["district"]))
   {
       $cty=$_POST["citylist"];
	   $district=$_POST["district"];
       addDistrict($cty,$district);
   }
	

		
	
?>

<!DOCTYPE html>
<html lang="en">
<head>
	<meta charset="utf-8" />
	<link rel="icon" type="image/png" href="assets/img/favicon.ico">
	<meta http-equiv="X-UA-Compatible" content="IE=edge,chrome=1" />

	<title>Light Bootstrap Dashboard by Creative Tim</title>

	<meta content='width=device-width, initial-scale=1.0, maximum-scale=1.0, user-scalable=0' name='viewport' />
    <meta name="viewport" content="width=device-width" />


    <!-- Bootstrap core CSS     -->
    <link href="assets/css/bootstrap.min.css" rel="stylesheet" />

    <!-- Animation library for notifications   -->
    <link href="assets/css/animate.min.css" rel="stylesheet"/>

    <!--  Light Bootstrap Table core CSS    -->
    <link href="assets/css/light-bootstrap-dashboard.css" rel="stylesheet"/>


    <!--  CSS for Demo Purpose, don't include it in your project     -->
    <link href="assets/css/demo.css" rel="stylesheet" />


    <!--     Fonts and icons     -->
    <link href="http://maxcdn.bootstrapcdn.com/font-awesome/4.2.0/css/font-awesome.min.css" rel="stylesheet">
    <link href='http://fonts.googleapis.com/css?family=Roboto:400,700,300' rel='stylesheet' type='text/css'>
    <link href="assets/css/pe-icon-7-stroke.css" rel="stylesheet" />
	<script src="https://ajax.googleapis.com/ajax/libs/jquery/3.2.0/jquery.min.js"></script>
	<script type="text/javascript">
			// JQuery 
			
			function myCity(_country){
							$.ajax({ // start an ajax POST 
					type	: "get",
					url		: "https://mapsweb.000webhostapp.com/WebServices/newcities.php",
					data 	:{country:_country},
					success : function(reply) { // when ajax executed successfully
						
						var text="<option value='0'> Choose City </option>";
						for(var x=0; x<reply.cities.length; x++)
						{
							text+="<option value="+reply.cities[x].id+">"+reply.cities[x].name+"</option>";
						}
						$("#citylist").html(text).show();	
						
						
					},
					error   : function(err) { // some unknown error happened
						console.log(err);
						alert(" There is an error! Please try again. " + err); 
					}
				});
					
			}
			
			
			
			$(document).ready(function(){
				
					$.ajax({ // start an ajax POST 
					type	: "get",
					url		: "https://mapsweb.000webhostapp.com/WebServices/countries.php",
					
					success : function(reply) { // when ajax executed successfully
						
						var text="<option value='0'> Choose Country </option>";
						for(var x=0; x<reply.countries.length; x++)
						{
							text+="<option value="+reply.countries[x]+">"+reply.countries[x]+"</option>";
						}
						$("#countrylist").html(text).show();	
						
						
					},
					error   : function(err) { // some unknown error happened
						console.log(err);
						alert(" There is an error! Please try again. " + err); 
					}
				});
				
					  
				
			});
				
			
			
			
		</script>
</head>
<body>

<div class="wrapper">
    <div class="sidebar" data-color="purple" data-image="assets/img/sidebar-5.jpg">

    <!--

        Tip 1: you can change the color of the sidebar using: data-color="blue | azure | green | orange | red | purple"
        Tip 2: you can also add an image using data-image tag

    -->

    	<div class="sidebar-wrapper">
            <div class="logo">
                <a href="#" class="simple-text">
                    MAPS WEB SERVICE
                </a>
            </div>

            <ul class="nav">
                <li class="#">
                    <a href="NewCountry.php">
                        <i class="pe-7s-map-marker"></i>
                        <p>New Country</p>
                    </a>
                </li>
                <li>
                    <a href="NewCity.php">
                        <i class="pe-7s-map-marker"></i>
                        <p>New City</p>
                    </a>
                </li>
                <li>
                    <a href="NewDistrict.php">
                        <i class="pe-7s-map-marker"></i>
                        <p>New District</p>
                    </a>
                </li>
				<li>
                    <a href="UpdateCountry.php">
                        <i class="pe-7s-map-marker"></i>
                        <p>Update Country</p>
                    </a>
                </li>
				<li>
                    <a href="UpdateCity.php">
                        <i class="pe-7s-map-marker"></i>
                        <p>Update City</p>
                    </a>
                </li>
				<li>
                    <a href="UpdateDistrict.php">
                        <i class="pe-7s-map-marker"></i>
                        <p>Update District</p>
                    </a>
                </li>
				<li>
                    <a href="DeleteCountry.php">
                        <i class="pe-7s-map-marker"></i>
                        <p>Delete Country</p>
                    </a>
                </li>
				<li>
                    <a href="DeleteCity.php">
                        <i class="pe-7s-map-marker"></i>
                        <p>Delete City</p>
                    </a>
                </li>
				<li>
                    <a href="DeleteDistrict.php">
                        <i class="pe-7s-map-marker"></i>
                        <p>Delete District</p>
                    </a>
                </li>
                
            </ul>
    	</div>
    </div>

    <div class="main-panel">
        <nav class="navbar navbar-default navbar-fixed">
            <div class="container-fluid">
                <div class="navbar-header">
                    <button type="button" class="navbar-toggle" data-toggle="collapse" data-target="#navigation-example-2">
                        <span class="sr-only">Toggle navigation</span>
                        <span class="icon-bar"></span>
                        <span class="icon-bar"></span>
                        <span class="icon-bar"></span>
                    </button>
                    <a class="navbar-brand" href="#"></a>
                </div>
                <div class="collapse navbar-collapse">
                   

                    <ul class="nav navbar-nav navbar-right">
					
						
						
                        <li>
                           <a href="Account.php">
                               <p>Account</p>
                            </a>
                        </li>
                       
                        <li>
                            <a href="/InfoMaps/index.php">
                                <p>Log out</p>
                            </a>
                        </li>
						<li class="separator hidden-lg hidden-md"></li>
                    </ul>
                </div>
            </div>
        </nav>


          <div class="content">
            <div class="container-fluid">
                <div class="row">
                    <div class="col-md-8">
                        <div class="card">
                            <div class="header">
                                <h4 class="title">Add District</h4>
                            </div>
                            <div class="content">
                                <form action="NewDistrict.php" method="POST">
                                    <div class="row">
                                        <div class="col-md-4">
											<div class="form-group">
                                                <label>Country Name : </label>
                                               <select class ="countrylist" id="countrylist" name="countrylist" onchange="myCity(this.value);"></select>
                                            </div>
											<div class="form-group">
                                                <label>City Name : </label>
                                               <select  class ="citylist" id="citylist" name="citylist" style="width:200px" ></select>
                                            </div>
                                            <div class="form-group">
                                                <label>District Name : </label>
                                                <input type="text" class="form-control" name="district" value="">
                                            </div>
											<div class="col-md-4">
										 <button type="submit" class="btn btn-info btn-fill pull-right">Add !!</button>
											</div> 
                                        </div>
                                       
                                   
                                    <div class="clearfix"></div>
                                </form>
                            </div>
                        </div>
                    </div>
                    

                </div>
            </div>
        </div>


    </div>
</div>

 

</body>

    <!--   Core JS Files   -->
    <script src="assets/js/jquery-1.10.2.js" type="text/javascript"></script>
	<script src="assets/js/bootstrap.min.js" type="text/javascript"></script>

	<!--  Checkbox, Radio & Switch Plugins -->
	<script src="assets/js/bootstrap-checkbox-radio-switch.js"></script>

	<!--  Charts Plugin -->
	<script src="assets/js/chartist.min.js"></script>

    <!--  Notifications Plugin    -->
    <script src="assets/js/bootstrap-notify.js"></script>

    <!--  Google Maps Plugin    -->
    <script type="text/javascript" src="https://maps.googleapis.com/maps/api/js?sensor=false"></script>

    <!-- Light Bootstrap Table Core javascript and methods for Demo purpose -->
	<script src="assets/js/light-bootstrap-dashboard.js"></script>

	<!-- Light Bootstrap Table DEMO methods, don't include it in your project! -->
	<script src="assets/js/demo.js"></script>

	<script type="text/javascript">
    	$(document).ready(function(){

        	demo.initChartist();

        	$.notify({
            	icon: 'pe-7s-gift',
            	message: "Welcome to <b>Light Bootstrap Dashboard</b> - a beautiful freebie for every web developer."

            },{
                type: 'info',
                timer: 4000
            });

    	});
	</script>
	
       
           

</html>