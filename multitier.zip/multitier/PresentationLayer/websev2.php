<?php
         header('Access-Control-Allow-Origin: *');
	require ('/storage/ssd1/934/1742934/public_html/DataLayer/DB.php');
	$db = new DB();
		if (isset($_GET['barcode'])) {
			$ct=$_GET['barcode'];
			$result = $db->getDataTable("select * from container where containerBarcode='$ct'");
			
			$allContainers = array();
			
			while($row = $result->fetch_assoc()) {
				$userObj = $row["containerBarcode"];
					
				array_push($allContainers, $userObj);
					
					
				}
				header('Content-Type: application/json; charset=utf-8');
				echo json_encode(array('cities'=>$allContainers),JSON_UNESCAPED_UNICODE);

			} 
?>