?php
         header('Access-Control-Allow-Origin: *');
	require ('/storage/ssd1/934/1742934/public_html/DataLayer/DB.php');
	$db = new DB();
		if (isset($_GET['country'])) {
			$ct=$_GET['country'];
			$result = $db->getDataTable("select * from ulke,il where ulke.Id=il.UlkeId AND ulke.UlkeAdi='$ct'");
			
			$allUsers = array();
			
			while($row = $result->fetch_assoc()) {
				$userObj = $row["IlAdi"];
					
				array_push($allUsers, $userObj);
					
					
				}
				header('Content-Type: application/json; charset=utf-8');
				echo json_encode(array('cities'=>$allUsers),JSON_UNESCAPED_UNICODE);

			} 
?>