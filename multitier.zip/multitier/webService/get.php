<?php

if (!empty($_GET['barcode']))
	$barcode = $_GET['barcode'];

$url = 'http://kaannedimoglu.000webhostapp.com/multitier/webService/request.php?barcode=' . $barcode;

//  Initiate curl
$ch = curl_init();
curl_setopt($ch, CURLOPT_SSL_VERIFYPEER, false);
curl_setopt($ch, CURLOPT_RETURNTRANSFER, true);
curl_setopt($ch, CURLOPT_URL,$url);
$result=curl_exec($ch);
curl_close($ch);

print_r(json_decode($result, true));