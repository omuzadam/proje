<?php
   if (!empty($_GET['barcode'])) {
      // connect DB
      $servername = "localhost";
      $username = "id1810188_root";
      $password = "cemocemo1";
      $dbname = "id1810188_container";
      
      $conn = new mysqli($servername, $username, $password, $dbname);
      
      if ($conn->connect_error) {
         die("Connection error: " . $conn->connect_error);
      }
      
      $conn->set_charset("utf8");
      
      $result = array();
      
      // read POST variables
      if (!empty($_GET['barcode'])) {
         $barcode = $_GET['barcode'];
         $barcode = "%" . $barcode . "%";
         // if (isset($_POST['capacity'])) {
            // prepare, bind and execute SQL statement
            $stmt = $conn->prepare("SELECT containerBarcode FROM container WHERE containerBarcode LIKE ?");
            $stmt->bind_param("s", $barcode);
            $stmt->execute();
            $stmt->bind_result($capacity,$departure);
            
            while ($stmt->fetch()) {
               array_push( $result, array("capacity"=>$capacity, "departure"=>$departure);
            }

            // print_r($result);
            
            $stmt->close(); // close statement
         /* } elseif (isset($_POST['route'])) {
            // prepare, bind and execute SQL statement
            $stmt = $conn->prepare("SELECT r.origin_point, r.destination_point, r.remain_travel_time, s.name
               FROM ships AS s 
               LEFT JOIN routes AS r ON (r.id = s.route_ID)
               WHERE s.name LIKE ?");
            $stmt->bind_param("s", $shipname);
            $stmt->execute();
            $stmt->bind_result($origin, $destination, $remain, $name);
            
            while ($stmt->fetch()) {
               array_push( $result, array("origin_point"=>$origin, "destination_point"=>$destination, "remain_travel_time" => $remain, "name" => $name) );
            }

            // print_r($result);
            
            $stmt->close(); // close statement
         } */
      }